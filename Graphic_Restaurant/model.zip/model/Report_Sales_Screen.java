package model;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Report_Sales_Screen extends Frame{ // �Ǹ� ������
	JTable sales;
	String data[][]={{"������", "40", "100000", "2015-1-1"}};
	String column[] = {"�޴�", "����", "�Ѿ�", "��¥"};
	
	Report_Sales_Screen(){
		sales = new JTable(data, column);
		sales.setBounds(30, 40, 600, 600);
		JScrollPane jsp = new JScrollPane(sales);
		add(jsp);
		
		
		setSize(800, 800);
		setLayout(null);
		setVisible(true);
		
		WindowAdapter WA = new WindowAdapter(){
			public void windowClosing(WindowEvent windowEvent){
				System.exit(0);
			}
		};
		addWindowListener(WA);
	}
	
	public static void main(String args[]){
		Report_Sales_Screen rss = new Report_Sales_Screen();
	}
}
